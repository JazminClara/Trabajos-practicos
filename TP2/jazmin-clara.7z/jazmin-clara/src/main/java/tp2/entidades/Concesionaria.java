package tp2.entidades;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Concesionaria {
    /**
     * Método Varargs que me permite agregar todos vehículos a una List<Vehiculo>
     * 
     * @param lista
     * @param vehiculos
     */
    public static void agregarVehiculos(List<Vehiculo> lista, Vehiculo... vehiculos) {
        for (Vehiculo v : vehiculos)
            lista.add(v);
    }

    /**
     * Crea instancias de Vehiculo, una List<Vehiculo> y agrega tales instancias a
     * dicha lista
     * 
     * @return List<Vehiculo>
     */
    public static List<Vehiculo> crearListVehiculos() {
        Vehiculo auto1 = new Auto("Peugeot", "206", 4, 200000.0);
        Vehiculo auto2 = new Auto("Peugeot", "208", 5, 250000.0);
        Vehiculo moto1 = new Moto("Honda", "Titan", 125, 60000.0);
        Vehiculo moto2 = new Moto("Yamaha", "YBR", 160, 80500.50);

        List<Vehiculo> lista = new ArrayList<>();
        Concesionaria.agregarVehiculos(lista, auto1, moto1, auto2, moto2);
        return lista;
    }

    /**
     * Imprime por pantalla el o los vehículo/s que tenga/n el precio más caro
     * 
     * @param lista
     */
    public static void calcularVehiculosMasCaros(List<Vehiculo> lista) {
        Double masCaro = lista.stream().max(Comparator.comparingDouble(Vehiculo::getPrecio)).get().getPrecio();

        System.out.print("Vehículo más caro: ");
        lista.stream().filter(p -> p.getPrecio().equals(masCaro))
                .forEach(p -> System.out.println(p.getMarca() + " " + p.getModelo()));
    }

    /**
     * Imprime por pantalla el o los vehículo/s que tenga/n el precio más barato
     * 
     * @param lista
     */
    public static void calcularVehiculosMasBaratos(List<Vehiculo> lista) {
        Double masBarato = lista.stream().min(Comparator.comparingDouble(Vehiculo::getPrecio)).get().getPrecio();

        System.out.print("Vehículo más barato: ");
        lista.stream().filter(p -> p.getPrecio().equals(masBarato))
                .forEach(p -> System.out.println(p.getMarca() + " " + p.getModelo()));
    }

    /**
     * Imprime por pantalla el/los vehículo/s que tengan determinada letra en el
     * atributo modelo
     * 
     * @param lista
     * @param letra
     */
    public static void buscarModelosQueContenga(List<Vehiculo> lista, String letra) {
        lista.stream().filter(p -> p.getModelo().toLowerCase().contains(letra.toLowerCase()))
                .forEach(p -> System.out.println("Vehículo que contiene en el modelo la letra '" + letra + "': "
                        + p.getMarca() + " " + p.getModelo() + " " + p.formatearPrecio(p.getPrecio())));
    }

    /**
     * Imprime por pantalla la lista de vehículos ordenada por precio descendente
     * 
     * @param lista
     */
    public static void ordenarPrecio(List<Vehiculo> lista) {
        lista.stream().sorted(Comparator.comparing(Vehiculo::getPrecio).reversed())
                .forEach(p -> System.out.println(p.getMarca() + " " + p.getModelo()));
    }

    /**
     * Imprime por pantalla la lista de vehículos ordenada por orden natural dado en
     * el compareTo()
     * en la clase Vehiculo
     * 
     * @param lista
     */
    public static void ordenarNatural(List<Vehiculo> lista) {
        lista.stream().sorted().forEach(System.out::println);
    }
}

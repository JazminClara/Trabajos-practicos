package tp2.entidades;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@EqualsAndHashCode
public abstract class Vehiculo implements Comparable<Vehiculo> {
    @Setter(AccessLevel.NONE)
    private String marca;
    @Setter(AccessLevel.NONE)
    private String modelo;
    private Double precio;

    /**
     * Método que me permite formatear un valor Double a un String donde "." separa
     * los miles y "," los decimales
     * 
     * @param numero
     * @return String
     */
    public String formatearPrecio(Double numero) {
        DecimalFormatSymbols simbolos = new DecimalFormatSymbols();
        simbolos.setDecimalSeparator(',');
        simbolos.setGroupingSeparator('.');
        DecimalFormat formato = new DecimalFormat("$#,##0.00", simbolos);
        return formato.format(numero);
    }

    @Override
    public int compareTo(Vehiculo aComparar) {
        String esteVehiculo = this.marca + "," + this.modelo + "," + this.precio;
        String otroVehiculo = aComparar.marca + "," + aComparar.modelo + "," + aComparar.precio;
        return esteVehiculo.compareTo(otroVehiculo);
    }
}

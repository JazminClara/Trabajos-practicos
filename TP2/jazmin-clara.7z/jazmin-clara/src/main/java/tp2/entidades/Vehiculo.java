package tp2.entidades;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public abstract class Vehiculo implements Comparable<Vehiculo> {
    @Setter(AccessLevel.NONE)
    private String marca;
    @Setter(AccessLevel.NONE)
    private String modelo;
    private Double precio;

    /**
     * Método que me permite formatear un valor Double a un String donde "." separa
     * los miles y "," los decimales
     * 
     * @param numero
     * @return String
     */
    public String formatearPrecio(Double numero) {
        DecimalFormat formato = new DecimalFormat("$#,##0.00");
        return formato.format(numero);
    }

    @Override
    public int compareTo(Vehiculo aComparar) {
        String esteVehiculo = String.format("%s,%s,%f", this.marca, this.modelo, this.precio);
        String otroVehiculo = String.format("%s,%s,%f", aComparar.marca, aComparar.modelo, aComparar.precio);
        return esteVehiculo.compareTo(otroVehiculo);
    }

}

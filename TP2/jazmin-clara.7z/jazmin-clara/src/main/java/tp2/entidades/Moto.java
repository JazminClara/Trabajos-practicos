package tp2.entidades;

import lombok.Getter;

@Getter
public class Moto extends Vehiculo {
    Integer cilindrada;

    public Moto(String marca, String modelo, Integer cilindrada, Double precio) {
        super(marca, modelo, precio);
        this.cilindrada = cilindrada;
    }
    
    @Override
    public String toString() {
        return String.format("Marca: %s // Modelo: %s // Cilindrada: %dc // Precio: %s",
                this.getMarca(), this.getModelo(), this.getCilindrada(), formatearPrecio(this.getPrecio()));
    }

}

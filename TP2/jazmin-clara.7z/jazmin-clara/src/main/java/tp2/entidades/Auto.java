package tp2.entidades;

import lombok.Getter;

@Getter
public class Auto extends Vehiculo {
    Integer puertas;

    public Auto(String marca, String modelo, Integer puertas, Double precio) {
        super(marca, modelo, precio);
        this.puertas = puertas;
    }

    @Override
    public String toString() {
        return String.format("Marca: %s // Modelo: %s // Puertas: %d // Precio: %s",
                this.getMarca(), this.getModelo(), this.getPuertas(), formatearPrecio(this.getPrecio()));

    }
}

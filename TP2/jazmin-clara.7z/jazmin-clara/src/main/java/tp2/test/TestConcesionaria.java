package tp2.test;

import java.util.List;

import tp2.entidades.Concesionaria;
import tp2.entidades.Vehiculo;

public class TestConcesionaria {
    public static void main(String[] args) {

        // Creación de lista de vehículos e impresión por pantalla
        List<Vehiculo> listaDeluxe = Concesionaria.crearListVehiculos();
        listaDeluxe.forEach(System.out::println);

        System.out.println("\n=============================\n");

        // Calcular instancias más caras o baratas de una lista
        Concesionaria.calcularVehiculosMasCaros(listaDeluxe);
        Concesionaria.calcularVehiculosMasBaratos(listaDeluxe);
        // Buscar instancias que contengan determinada letra
        Concesionaria.buscarModelosQueContenga(listaDeluxe, "Y");

        System.out.println("\n=============================\n");

        // Ordenar lista por precio descendente
        System.out.println("Vehículos ordenados por precio de mayor a menor:\r");
        Concesionaria.ordenarPrecio(listaDeluxe);

        System.out.println("\n=============================\n");

        // Ordenar lista por orden natural
        System.out.println("Vehículos ordenados por orden natural (marca, modelo, precio):");
        Concesionaria.ordenarNatural(listaDeluxe);

    } 
}
